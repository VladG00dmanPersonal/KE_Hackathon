import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-change-me-for-production")
    DATABASE = os.environ.get("DATABASE", os.path.join(BASE_DIR, "instance", "app.sqlite3"))
    ITEMS_PER_PAGE = 12
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024
    UPLOAD_FOLDER = os.environ.get("UPLOAD_FOLDER", os.path.join(BASE_DIR, "app", "static", "uploads"))
