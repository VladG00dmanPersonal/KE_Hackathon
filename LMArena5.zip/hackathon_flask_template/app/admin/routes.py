import re
import sqlite3
from datetime import datetime

from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from ..auth.decorators import roles_required
from ..db import execute, get_db, query_all, query_one

bp = Blueprint("admin", __name__)

CYRILLIC_MAP = str.maketrans({
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e",
    "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
    "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
    "ф": "f", "х": "h", "ц": "c", "ч": "ch", "ш": "sh", "щ": "sch", "ъ": "",
    "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
})


def slugify(value):
    value = (value or "").strip().lower().translate(CYRILLIC_MAP)
    value = re.sub(r"[^a-z0-9]+", "-", value).strip("-")
    return value


def unique_slug(base, table_name, exclude_id=None):
    base = slugify(base) or f"item-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
    slug = base
    counter = 2
    while True:
        if exclude_id is None:
            exists = query_one(f"SELECT id FROM {table_name} WHERE slug = ?", (slug,))
        else:
            exists = query_one(f"SELECT id FROM {table_name} WHERE slug = ? AND id != ?", (slug, exclude_id))
        if not exists:
            return slug
        slug = f"{base}-{counter}"
        counter += 1


def parse_money(value, field_name="Сумма"):
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        raise ValueError(f"{field_name} должна быть целым числом.")
    if parsed < 0:
        raise ValueError(f"{field_name} не может быть отрицательной.")
    return parsed


def handle_category_from_form():
    category_id = request.form.get("category_id", type=int)
    new_category = request.form.get("new_category", "").strip()
    if new_category:
        existing = query_one("SELECT id FROM categories WHERE lower(name) = lower(?)", (new_category,))
        if existing:
            return existing["id"]
        category_slug = unique_slug(new_category, "categories")
        execute("INSERT INTO categories (slug, name) VALUES (?, ?)", (category_slug, new_category), commit=True)
        return query_one("SELECT id FROM categories WHERE slug = ?", (category_slug,))["id"]
    return category_id


def product_payload(product_id=None):
    name = request.form.get("name", "").strip()
    raw_slug = request.form.get("slug", "").strip()
    description = request.form.get("description", "").strip()
    image_url = request.form.get("image_url", "").strip() or None
    in_stock = 1 if request.form.get("in_stock") == "1" else 0

    if not name:
        raise ValueError("Укажите название товара.")
    price = parse_money(request.form.get("price"), "Цена")
    category_id = handle_category_from_form()

    if raw_slug:
        slug = slugify(raw_slug)
        if not slug:
            raise ValueError("Slug должен содержать латинские буквы или цифры.")
        exists = query_one("SELECT id FROM products WHERE slug = ? AND (? IS NULL OR id != ?)", (slug, product_id, product_id))
        if exists:
            raise ValueError("Товар с таким slug уже существует. Укажите другой slug.")
    else:
        slug = unique_slug(name, "products", exclude_id=product_id)

    return {
        "name": name,
        "slug": slug,
        "description": description,
        "price": price,
        "image_url": image_url,
        "category_id": category_id,
        "in_stock": in_stock,
    }


@bp.route("/")
@roles_required("admin")
def dashboard():
    stats = {
        "users": query_one("SELECT COUNT(*) AS value FROM users")["value"],
        "products": query_one("SELECT COUNT(*) AS value FROM products")["value"],
        "events": query_one("SELECT COUNT(*) AS value FROM calendar_events")["value"],
        "cart_items": query_one("SELECT COUNT(*) AS value FROM cart_items")["value"],
        "orders": query_one("SELECT COUNT(*) AS value FROM orders")["value"],
        "pending_topups": query_one("SELECT COUNT(*) AS value FROM balance_requests WHERE status = 'pending'")["value"],
    }
    return render_template("admin/dashboard.html", stats=stats)


@bp.route("/users", methods=("GET", "POST"))
@roles_required("admin")
def users():
    if request.method == "POST":
        user_id = request.form.get("user_id", type=int)
        role = request.form.get("role", "user")
        if role not in {"user", "manager", "admin"}:
            flash("Некорректная роль.", "danger")
        else:
            execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id), commit=True)
            flash("Роль пользователя обновлена.", "success")
        return redirect(url_for("admin.users"))

    users = query_all("SELECT id, email, role, full_name, balance, created_at FROM users ORDER BY created_at DESC")
    return render_template("admin/users.html", users=users)


@bp.route("/products")
@roles_required("admin")
def products():
    products = query_all(
        """
        SELECT p.*, c.name AS category_name
        FROM products p
        LEFT JOIN categories c ON c.id = p.category_id
        ORDER BY p.created_at DESC, p.id DESC
        """
    )
    return render_template("admin/products.html", products=products)


@bp.route("/products/new", methods=("GET", "POST"))
@roles_required("admin")
def product_new():
    categories = query_all("SELECT * FROM categories ORDER BY name")

    if request.method == "POST":
        try:
            payload = product_payload()
            execute(
                """
                INSERT INTO products (slug, name, description, price, image_url, category_id, in_stock)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (payload["slug"], payload["name"], payload["description"], payload["price"], payload["image_url"], payload["category_id"], payload["in_stock"]),
                commit=True,
            )
        except (ValueError, sqlite3.IntegrityError) as exc:
            flash(str(exc) if str(exc) else "Не удалось добавить товар.", "danger")
            return render_template("admin/product_form.html", categories=categories, form=request.form, product=None, mode="create")

        flash("Товар добавлен.", "success")
        return redirect(url_for("admin.products"))

    return render_template("admin/product_form.html", categories=categories, form={}, product=None, mode="create")


@bp.route("/products/<int:product_id>/edit", methods=("GET", "POST"))
@roles_required("admin")
def product_edit(product_id):
    product = query_one("SELECT * FROM products WHERE id = ?", (product_id,))
    if product is None:
        flash("Товар не найден.", "danger")
        return redirect(url_for("admin.products"))

    categories = query_all("SELECT * FROM categories ORDER BY name")
    if request.method == "POST":
        try:
            payload = product_payload(product_id=product_id)
            execute(
                """
                UPDATE products
                SET slug = ?, name = ?, description = ?, price = ?, image_url = ?, category_id = ?, in_stock = ?
                WHERE id = ?
                """,
                (payload["slug"], payload["name"], payload["description"], payload["price"], payload["image_url"], payload["category_id"], payload["in_stock"], product_id),
                commit=True,
            )
        except (ValueError, sqlite3.IntegrityError) as exc:
            flash(str(exc) if str(exc) else "Не удалось обновить товар.", "danger")
            return render_template("admin/product_form.html", categories=categories, form=request.form, product=product, mode="edit")

        flash("Товар обновлён.", "success")
        return redirect(url_for("admin.products"))

    return render_template("admin/product_form.html", categories=categories, form=dict(product), product=product, mode="edit")


@bp.route("/products/<int:product_id>/delete", methods=("POST",))
@roles_required("admin")
def product_delete(product_id):
    execute("DELETE FROM products WHERE id = ?", (product_id,), commit=True)
    flash("Товар удалён.", "info")
    return redirect(url_for("admin.products"))


@bp.route("/topups")
@roles_required("admin")
def topups():
    status = request.args.get("status", "pending")
    params = []
    sql = """
        SELECT br.*, u.email, u.full_name
        FROM balance_requests br
        JOIN users u ON u.id = br.user_id
        WHERE 1=1
    """
    if status:
        sql += " AND br.status = ?"
        params.append(status)
    sql += " ORDER BY br.created_at DESC, br.id DESC"
    requests = query_all(sql, params)
    return render_template("admin/topups.html", requests=requests, selected_status=status)


@bp.route("/topups/<int:request_id>/review", methods=("POST",))
@roles_required("admin")
def topup_review(request_id):
    action = request.form.get("action")
    comment = request.form.get("admin_comment", "").strip() or None
    topup = query_one("SELECT * FROM balance_requests WHERE id = ?", (request_id,))
    if topup is None:
        flash("Заявка не найдена.", "danger")
        return redirect(url_for("admin.topups"))
    if topup["status"] != "pending":
        flash("Эта заявка уже обработана.", "warning")
        return redirect(url_for("admin.topups"))
    if action not in {"approved", "rejected"}:
        flash("Некорректное действие.", "danger")
        return redirect(url_for("admin.topups"))

    conn = get_db()
    try:
        if action == "approved":
            conn.execute("UPDATE users SET balance = balance + ? WHERE id = ?", (topup["amount"], topup["user_id"]))
        conn.execute(
            """
            UPDATE balance_requests
            SET status = ?, admin_comment = ?, reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (action, comment, g.user["id"], request_id),
        )
        conn.commit()
    except Exception:
        conn.rollback()
        flash("Не удалось обработать заявку.", "danger")
        return redirect(url_for("admin.topups"))

    flash("Заявка подтверждена." if action == "approved" else "Заявка отклонена.", "success")
    return redirect(url_for("admin.topups"))
