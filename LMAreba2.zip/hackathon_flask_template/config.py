import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-change-me-for-production")
    DATABASE = os.environ.get("DATABASE", os.path.join(BASE_DIR, "instance", "app.sqlite3"))
    ITEMS_PER_PAGE = 12
