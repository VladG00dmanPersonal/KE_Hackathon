import sqlite3
from pathlib import Path

import click
from flask import current_app, g
from werkzeug.security import generate_password_hash


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(e=None):
    database = g.pop("db", None)
    if database is not None:
        database.close()


def execute(sql, params=(), commit=False):
    conn = get_db()
    cur = conn.execute(sql, params)
    if commit:
        conn.commit()
    return cur


def query_one(sql, params=()):
    return execute(sql, params).fetchone()


def query_all(sql, params=()):
    return execute(sql, params).fetchall()


def init_db():
    conn = get_db()
    schema_path = Path(current_app.root_path) / "schema.sql"
    conn.executescript(schema_path.read_text(encoding="utf-8"))
    conn.commit()


def seed_db():
    conn = get_db()

    conn.execute(
        """
        INSERT OR IGNORE INTO users (email, password_hash, role, full_name, balance)
        VALUES (?, ?, ?, ?, ?)
        """,
        ("admin@example.com", generate_password_hash("admin123"), "admin", "Администратор", 1_000_000),
    )
    conn.execute(
        """
        INSERT OR IGNORE INTO users (email, password_hash, role, full_name, balance)
        VALUES (?, ?, ?, ?, ?)
        """,
        ("user@example.com", generate_password_hash("user123"), "user", "Тестовый пользователь", 200_000),
    )

    categories = [
        ("electronics", "Электроника"),
        ("books", "Книги"),
        ("home", "Дом"),
        ("sport", "Спорт"),
    ]
    conn.executemany(
        "INSERT OR IGNORE INTO categories (slug, name) VALUES (?, ?)",
        categories,
    )

    cat_ids = {row["slug"]: row["id"] for row in conn.execute("SELECT id, slug FROM categories")}
    products = [
        ("notebook-pro", "Ноутбук Pro", "Рабочий ноутбук для разработки и дизайна.", 129900, cat_ids["electronics"], 1),
        ("wireless-mouse", "Беспроводная мышь", "Компактная мышь с тихими кнопками.", 2490, cat_ids["electronics"], 1),
        ("python-handbook", "Справочник Python", "Книга с базовыми и продвинутыми примерами.", 1800, cat_ids["books"], 1),
        ("clean-desk-lamp", "Настольная лампа", "Минималистичная лампа для рабочего стола.", 3200, cat_ids["home"], 1),
        ("yoga-mat", "Коврик для йоги", "Нескользящий коврик для тренировок.", 2100, cat_ids["sport"], 0),
        ("thermal-bottle", "Термобутылка", "Бутылка 500 мл для офиса и прогулок.", 1400, cat_ids["sport"], 1),
    ]
    conn.executemany(
        """
        INSERT OR IGNORE INTO products
            (slug, name, description, price, category_id, in_stock)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        products,
    )

    table_records = [
        ("Заявка на подключение", "new", "client1@example.com", 12000),
        ("Поставка оборудования", "in_progress", "client2@example.com", 53000),
        ("Договор поддержки", "done", "client3@example.com", 18000),
        ("Обновление каталога", "new", "client4@example.com", 0),
    ]
    conn.executemany(
        """
        INSERT OR IGNORE INTO table_records (title, status, owner_email, amount)
        VALUES (?, ?, ?, ?)
        """,
        table_records,
    )

    conn.commit()


@click.command("init-db")
def init_db_command():
    init_db()
    seed_db()
    click.echo("База данных создана и заполнена тестовыми данными.")


def init_app(app):
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)
