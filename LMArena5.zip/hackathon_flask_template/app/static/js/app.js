document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.querySelector('[data-nav-toggle]');
    const nav = document.querySelector('[data-nav]');

    if (toggle && nav) {
        toggle.addEventListener('click', () => {
            nav.classList.toggle('is-open');
        });
    }

    document.querySelectorAll('form[data-confirm]').forEach((form) => {
        form.addEventListener('submit', (event) => {
            const message = form.getAttribute('data-confirm') || 'Подтвердить действие?';
            if (!window.confirm(message)) {
                event.preventDefault();
            }
        });
    });

    document.querySelectorAll('[data-range-input]').forEach((input) => {
        const output = input.closest('label')?.querySelector('[data-range-output]');
        const update = () => { if (output) output.textContent = input.value; };
        input.addEventListener('input', update);
        update();
    });

    if (window.STATS_DATA_URL) {
        loadStatsCharts(window.STATS_DATA_URL);
    }
});

async function loadStatsCharts(url) {
    try {
        const response = await fetch(url);
        const data = await response.json();
        document.querySelectorAll('canvas[data-chart]').forEach((canvas) => {
            const key = canvas.dataset.chart;
            const type = canvas.dataset.type || 'bar';
            const rows = data[key] || [];
            drawChart(canvas, rows, type);
        });
    } catch (error) {
        console.error('Не удалось загрузить статистику', error);
    }
}

function drawChart(canvas, rows, type = 'bar') {
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    const padding = 44;
    const maxValue = Math.max(1, ...rows.map((row) => Number(row.value || 0)));

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
        const y = padding + ((height - padding * 2) / 4) * i;
        ctx.beginPath();
        ctx.moveTo(padding, y);
        ctx.lineTo(width - padding, y);
        ctx.stroke();
    }

    if (!rows.length) {
        ctx.fillStyle = '#6b7280';
        ctx.font = '16px system-ui';
        ctx.fillText('Нет данных для графика', padding, height / 2);
        return;
    }

    if (type === 'line') {
        drawLineChart(ctx, rows, width, height, padding, maxValue);
    } else {
        drawBarChart(ctx, rows, width, height, padding, maxValue);
    }
}

function drawBarChart(ctx, rows, width, height, padding, maxValue) {
    const gap = 14;
    const chartWidth = width - padding * 2;
    const barWidth = Math.max(18, (chartWidth - gap * (rows.length - 1)) / rows.length);

    rows.forEach((row, index) => {
        const value = Number(row.value || 0);
        const barHeight = ((height - padding * 2) * value) / maxValue;
        const x = padding + index * (barWidth + gap);
        const y = height - padding - barHeight;

        ctx.fillStyle = '#111827';
        ctx.fillRect(x, y, barWidth, barHeight);
        ctx.fillStyle = '#6b7280';
        ctx.font = '12px system-ui';
        ctx.fillText(shortLabel(row.label), x, height - 16);
        ctx.fillStyle = '#111827';
        ctx.fillText(String(value), x, Math.max(16, y - 8));
    });
}

function drawLineChart(ctx, rows, width, height, padding, maxValue) {
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    const points = rows.map((row, index) => {
        const x = rows.length === 1 ? padding + chartWidth / 2 : padding + (chartWidth / (rows.length - 1)) * index;
        const y = height - padding - (chartHeight * Number(row.value || 0)) / maxValue;
        return { x, y, row };
    });

    ctx.strokeStyle = '#111827';
    ctx.lineWidth = 3;
    ctx.beginPath();
    points.forEach((point, index) => {
        if (index === 0) ctx.moveTo(point.x, point.y);
        else ctx.lineTo(point.x, point.y);
    });
    ctx.stroke();

    points.forEach((point) => {
        ctx.fillStyle = '#111827';
        ctx.beginPath();
        ctx.arc(point.x, point.y, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#6b7280';
        ctx.font = '12px system-ui';
        ctx.fillText(shortLabel(point.row.label), point.x - 24, height - 16);
        ctx.fillStyle = '#111827';
        ctx.fillText(String(point.row.value), point.x - 8, point.y - 10);
    });
}

function shortLabel(label) {
    label = String(label || '—');
    return label.length > 12 ? label.slice(0, 12) + '…' : label;
}
