from flask import Blueprint, render_template

bp = Blueprint("game", __name__)


@bp.route("/")
def snake():
    return render_template("game/snake.html")
