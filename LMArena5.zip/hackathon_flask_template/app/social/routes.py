from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from ..auth.decorators import login_required
from ..db import execute, query_all, query_one

bp = Blueprint("social", __name__)


def get_user(user_id):
    return query_one(
        "SELECT id, email, full_name, role, created_at FROM users WHERE id = ?",
        (user_id,),
    )


def get_conversations(limit=None):
    sql = """
        SELECT
            u.id,
            u.email,
            u.full_name,
            u.role,
            (
                SELECT dm.body
                FROM direct_messages dm
                WHERE (dm.sender_id = ? AND dm.recipient_id = u.id)
                   OR (dm.sender_id = u.id AND dm.recipient_id = ?)
                ORDER BY dm.created_at DESC, dm.id DESC
                LIMIT 1
            ) AS last_body,
            (
                SELECT dm.created_at
                FROM direct_messages dm
                WHERE (dm.sender_id = ? AND dm.recipient_id = u.id)
                   OR (dm.sender_id = u.id AND dm.recipient_id = ?)
                ORDER BY dm.created_at DESC, dm.id DESC
                LIMIT 1
            ) AS last_at,
            (
                SELECT COUNT(*)
                FROM direct_messages dm
                WHERE dm.sender_id = u.id
                  AND dm.recipient_id = ?
                  AND dm.is_read = 0
            ) AS unread_count
        FROM users u
        WHERE u.id != ?
          AND EXISTS (
                SELECT 1
                FROM direct_messages dm
                WHERE (dm.sender_id = ? AND dm.recipient_id = u.id)
                   OR (dm.sender_id = u.id AND dm.recipient_id = ?)
          )
        ORDER BY last_at DESC, u.id DESC
    """
    params = [g.user["id"], g.user["id"], g.user["id"], g.user["id"], g.user["id"], g.user["id"], g.user["id"], g.user["id"]]
    if limit:
        sql += " LIMIT ?"
        params.append(limit)
    return query_all(sql, params)


def get_users(search="", limit=None):
    sql = """
        SELECT id, email, full_name, role, created_at
        FROM users
        WHERE id != ?
    """
    params = [g.user["id"]]
    if search:
        sql += " AND (email LIKE ? OR full_name LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    sql += " ORDER BY COALESCE(full_name, email) ASC"
    if limit:
        sql += " LIMIT ?"
        params.append(limit)
    return query_all(sql, params)


@bp.route("/", methods=("GET", "POST"))
@login_required
def index():
    if request.method == "POST":
        content = request.form.get("content", "").strip()
        if not content:
            flash("Напишите текст публикации.", "danger")
        elif len(content) > 1000:
            flash("Публикация должна быть не длиннее 1000 символов.", "danger")
        else:
            execute(
                "INSERT INTO social_posts (user_id, content) VALUES (?, ?)",
                (g.user["id"], content),
                commit=True,
            )
            flash("Публикация добавлена.", "success")
            return redirect(url_for("social.index"))

    search = request.args.get("q", "").strip()
    users = get_users(search=search, limit=12)
    posts = query_all(
        """
        SELECT sp.*, u.email, u.full_name, u.role
        FROM social_posts sp
        JOIN users u ON u.id = sp.user_id
        ORDER BY sp.created_at DESC, sp.id DESC
        LIMIT 30
        """
    )
    conversations = get_conversations(limit=6)
    unread_total = query_one(
        "SELECT COUNT(*) AS value FROM direct_messages WHERE recipient_id = ? AND is_read = 0",
        (g.user["id"],),
    )["value"]
    return render_template(
        "social/index.html",
        users=users,
        posts=posts,
        conversations=conversations,
        search=search,
        unread_total=unread_total,
    )


@bp.route("/messages")
@login_required
def messages():
    search = request.args.get("q", "").strip()
    conversations = get_conversations()
    users = get_users(search=search, limit=30)
    unread_total = query_one(
        "SELECT COUNT(*) AS value FROM direct_messages WHERE recipient_id = ? AND is_read = 0",
        (g.user["id"],),
    )["value"]
    return render_template(
        "social/messages.html",
        conversations=conversations,
        users=users,
        search=search,
        unread_total=unread_total,
    )


@bp.route("/messages/<int:user_id>", methods=("GET", "POST"))
@login_required
def thread(user_id):
    target_user = get_user(user_id)
    if target_user is None:
        flash("Пользователь не найден.", "danger")
        return redirect(url_for("social.messages"))
    if target_user["id"] == g.user["id"]:
        flash("Нельзя открыть диалог с самим собой.", "warning")
        return redirect(url_for("social.messages"))

    if request.method == "POST":
        body = request.form.get("body", "").strip()
        if not body:
            flash("Сообщение не может быть пустым.", "danger")
        elif len(body) > 2000:
            flash("Сообщение должно быть не длиннее 2000 символов.", "danger")
        else:
            execute(
                """
                INSERT INTO direct_messages (sender_id, recipient_id, body)
                VALUES (?, ?, ?)
                """,
                (g.user["id"], target_user["id"], body),
                commit=True,
            )
            return redirect(url_for("social.thread", user_id=target_user["id"]))

    execute(
        """
        UPDATE direct_messages
        SET is_read = 1
        WHERE sender_id = ? AND recipient_id = ? AND is_read = 0
        """,
        (target_user["id"], g.user["id"]),
        commit=True,
    )

    thread_messages = query_all(
        """
        SELECT dm.*, sender.email AS sender_email, sender.full_name AS sender_name
        FROM direct_messages dm
        JOIN users sender ON sender.id = dm.sender_id
        WHERE (dm.sender_id = ? AND dm.recipient_id = ?)
           OR (dm.sender_id = ? AND dm.recipient_id = ?)
        ORDER BY dm.created_at ASC, dm.id ASC
        """,
        (g.user["id"], target_user["id"], target_user["id"], g.user["id"]),
    )
    conversations = get_conversations(limit=10)
    return render_template(
        "social/thread.html",
        target_user=target_user,
        thread_messages=thread_messages,
        conversations=conversations,
    )
