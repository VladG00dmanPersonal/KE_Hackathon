from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from ..auth.decorators import login_required
from ..db import execute, query_all, query_one

bp = Blueprint("profile", __name__)


@bp.route("/", methods=("GET", "POST"))
@login_required
def index():
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        phone = request.form.get("phone", "").strip()
        execute(
            "UPDATE users SET full_name = ?, phone = ? WHERE id = ?",
            (full_name, phone, g.user["id"]),
            commit=True,
        )
        flash("Профиль обновлён.", "success")
        return redirect(url_for("profile.index"))

    stats = {
        "cart_count": query_one("SELECT COALESCE(SUM(quantity), 0) AS value FROM cart_items WHERE user_id = ?", (g.user["id"],))["value"],
        "events_count": query_one("SELECT COUNT(*) AS value FROM calendar_events WHERE user_id = ?", (g.user["id"],))["value"],
        "orders_count": query_one("SELECT COUNT(*) AS value FROM orders WHERE user_id = ?", (g.user["id"],))["value"],
    }
    orders = query_all(
        """
        SELECT o.*, COUNT(oi.id) AS items_count
        FROM orders o
        LEFT JOIN order_items oi ON oi.order_id = o.id
        WHERE o.user_id = ?
        GROUP BY o.id
        ORDER BY o.created_at DESC, o.id DESC
        LIMIT 10
        """,
        (g.user["id"],),
    )
    return render_template("profile/index.html", stats=stats, orders=orders)


@bp.route("/top-up", methods=("POST",))
@login_required
def top_up():
    raw_amount = request.form.get("amount", "").strip()
    try:
        amount = int(raw_amount)
    except ValueError:
        flash("Сумма пополнения должна быть целым числом.", "danger")
        return redirect(url_for("profile.index"))

    if amount <= 0:
        flash("Сумма пополнения должна быть больше нуля.", "danger")
        return redirect(url_for("profile.index"))
    if amount > 1_000_000:
        flash("Для шаблона максимальная сумма одного пополнения — 1 000 000 ₽.", "warning")
        return redirect(url_for("profile.index"))

    execute("UPDATE users SET balance = balance + ? WHERE id = ?", (amount, g.user["id"]), commit=True)
    flash("Баланс пополнен.", "success")
    return redirect(url_for("profile.index"))
