from flask import Blueprint, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from ..db import execute, query_one

bp = Blueprint("auth", __name__)


@bp.before_app_request
def load_logged_in_user():
    user_id = session.get("user_id")
    if user_id is None:
        g.user = None
    else:
        g.user = query_one("SELECT * FROM users WHERE id = ?", (user_id,))


@bp.route("/register", methods=("GET", "POST"))
def register():
    if g.user:
        return redirect(url_for("profile.index"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        password_confirm = request.form.get("password_confirm", "")
        full_name = request.form.get("full_name", "").strip()

        error = None
        if not email:
            error = "Укажите почту."
        elif "@" not in email:
            error = "Почта выглядит некорректно."
        elif len(password) < 6:
            error = "Пароль должен быть не короче 6 символов."
        elif password != password_confirm:
            error = "Пароли не совпадают."
        elif query_one("SELECT id FROM users WHERE email = ?", (email,)):
            error = "Пользователь с такой почтой уже существует."

        if error is None:
            execute(
                """
                INSERT INTO users (email, password_hash, role, full_name)
                VALUES (?, ?, 'user', ?)
                """,
                (email, generate_password_hash(password), full_name),
                commit=True,
            )
            flash("Аккаунт создан. Теперь войдите.", "success")
            return redirect(url_for("auth.login"))

        flash(error, "danger")

    return render_template("auth/register.html")


@bp.route("/login", methods=("GET", "POST"))
def login():
    if g.user:
        return redirect(url_for("profile.index"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = query_one("SELECT * FROM users WHERE email = ?", (email,))

        if user is None or not check_password_hash(user["password_hash"], password):
            flash("Неверная почта или пароль.", "danger")
        else:
            session.clear()
            session["user_id"] = user["id"]
            flash("Вы вошли в аккаунт.", "success")
            return redirect(request.args.get("next") or url_for("main.index"))

    return render_template("auth/login.html")


@bp.route("/logout", methods=("POST",))
def logout():
    session.clear()
    flash("Вы вышли из аккаунта.", "info")
    return redirect(url_for("main.index"))
