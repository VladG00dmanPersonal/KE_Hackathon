from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from ..auth.decorators import login_required
from ..db import execute, get_db, query_all, query_one

bp = Blueprint("cart", __name__)


def get_cart_items(user_id):
    return query_all(
        """
        SELECT ci.*, p.name, p.slug, p.price, p.in_stock, c.name AS category_name,
               (ci.quantity * p.price) AS line_total
        FROM cart_items ci
        JOIN products p ON p.id = ci.product_id
        LEFT JOIN categories c ON c.id = p.category_id
        WHERE ci.user_id = ?
        ORDER BY ci.created_at DESC
        """,
        (user_id,),
    )


@bp.route("/")
@login_required
def index():
    items = get_cart_items(g.user["id"])
    total = sum(item["line_total"] for item in items)
    return render_template("cart/index.html", items=items, total=total)


@bp.route("/add/<int:product_id>", methods=("POST",))
@login_required
def add(product_id):
    product = query_one("SELECT id, name, in_stock FROM products WHERE id = ?", (product_id,))
    if product is None:
        flash("Товар не найден.", "danger")
        return redirect(url_for("products.catalog"))
    if not product["in_stock"]:
        flash("Товар сейчас недоступен.", "warning")
        return redirect(request.referrer or url_for("products.catalog"))

    quantity = request.form.get("quantity", "1")
    try:
        quantity = max(1, int(quantity))
    except ValueError:
        quantity = 1

    execute(
        """
        INSERT INTO cart_items (user_id, product_id, quantity)
        VALUES (?, ?, ?)
        ON CONFLICT(user_id, product_id) DO UPDATE SET
            quantity = quantity + excluded.quantity,
            updated_at = CURRENT_TIMESTAMP
        """,
        (g.user["id"], product_id, quantity),
        commit=True,
    )
    flash("Товар добавлен в корзину.", "success")
    return redirect(request.referrer or url_for("cart.index"))


@bp.route("/update/<int:item_id>", methods=("POST",))
@login_required
def update(item_id):
    quantity = request.form.get("quantity", "1")
    try:
        quantity = max(1, int(quantity))
    except ValueError:
        quantity = 1

    execute(
        """
        UPDATE cart_items
        SET quantity = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ? AND user_id = ?
        """,
        (quantity, item_id, g.user["id"]),
        commit=True,
    )
    flash("Количество обновлено.", "success")
    return redirect(url_for("cart.index"))


@bp.route("/remove/<int:item_id>", methods=("POST",))
@login_required
def remove(item_id):
    execute("DELETE FROM cart_items WHERE id = ? AND user_id = ?", (item_id, g.user["id"]), commit=True)
    flash("Товар удалён из корзины.", "info")
    return redirect(url_for("cart.index"))


@bp.route("/clear", methods=("POST",))
@login_required
def clear():
    execute("DELETE FROM cart_items WHERE user_id = ?", (g.user["id"],), commit=True)
    flash("Корзина очищена.", "info")
    return redirect(url_for("cart.index"))


@bp.route("/checkout", methods=("POST",))
@login_required
def checkout():
    items = get_cart_items(g.user["id"])
    if not items:
        flash("Корзина пустая.", "warning")
        return redirect(url_for("cart.index"))

    unavailable = [item["name"] for item in items if not item["in_stock"]]
    if unavailable:
        flash("Некоторые товары недоступны: " + ", ".join(unavailable), "danger")
        return redirect(url_for("cart.index"))

    total = sum(item["line_total"] for item in items)
    user = query_one("SELECT balance FROM users WHERE id = ?", (g.user["id"],))
    balance = user["balance"] if user else 0

    if balance < total:
        flash("Недостаточно средств на балансе. Пополните баланс в профиле.", "warning")
        return redirect(url_for("cart.index"))

    conn = get_db()
    try:
        cur = conn.execute(
            "INSERT INTO orders (user_id, total, status) VALUES (?, ?, 'paid')",
            (g.user["id"], total),
        )
        order_id = cur.lastrowid
        conn.executemany(
            """
            INSERT INTO order_items
                (order_id, product_id, product_name, product_slug, price, quantity)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            [
                (order_id, item["product_id"], item["name"], item["slug"], item["price"], item["quantity"])
                for item in items
            ],
        )
        conn.execute("UPDATE users SET balance = balance - ? WHERE id = ?", (total, g.user["id"]))
        conn.execute("DELETE FROM cart_items WHERE user_id = ?", (g.user["id"],))
        conn.commit()
    except Exception:
        conn.rollback()
        flash("Не удалось оформить заказ. Попробуйте ещё раз.", "danger")
        return redirect(url_for("cart.index"))

    flash(f"Заказ №{order_id} оформлен и оплачен с баланса.", "success")
    return redirect(url_for("profile.index"))
