class SnakeGame {
    constructor(options) {
        this.canvas = options.canvas;
        this.ctx = this.canvas.getContext('2d');
        this.scoreElement = options.scoreElement;
        this.bestElement = options.bestElement;
        this.startButton = options.startButton;
        this.pauseButton = options.pauseButton;
        this.resetButton = options.resetButton;
        this.mobileButtons = options.mobileButtons || [];

        this.gridSize = options.gridSize || 24;
        this.cellSize = this.canvas.width / this.gridSize;
        this.tickMs = options.tickMs || 110;
        this.storageKey = 'hackathon-template-snake-best';

        this.timer = null;
        this.isRunning = false;
        this.isPaused = false;
        this.gameOver = false;
        this.best = Number(localStorage.getItem(this.storageKey) || 0);

        this.resetState();
        this.bindEvents();
        this.render();
        this.updateUi();
    }

    resetState() {
        const center = Math.floor(this.gridSize / 2);
        this.snake = [
            { x: center, y: center },
            { x: center - 1, y: center },
            { x: center - 2, y: center },
        ];
        this.direction = { x: 1, y: 0 };
        this.nextDirection = { x: 1, y: 0 };
        this.score = 0;
        this.food = this.createFood();
        this.isPaused = false;
        this.gameOver = false;
    }

    bindEvents() {
        document.addEventListener('keydown', (event) => this.handleKeydown(event));
        this.startButton?.addEventListener('click', () => this.start());
        this.pauseButton?.addEventListener('click', () => this.togglePause());
        this.resetButton?.addEventListener('click', () => this.reset());

        this.mobileButtons.forEach((button) => {
            button.addEventListener('click', () => {
                this.setDirection(button.dataset.snakeDir);
                if (!this.isRunning) this.start();
            });
        });

        this.canvas.addEventListener('click', () => this.canvas.focus());
    }

    handleKeydown(event) {
        const keyMap = {
            ArrowUp: 'up',
            KeyW: 'up',
            ArrowDown: 'down',
            KeyS: 'down',
            ArrowLeft: 'left',
            KeyA: 'left',
            ArrowRight: 'right',
            KeyD: 'right',
        };

        if (keyMap[event.code]) {
            event.preventDefault();
            this.setDirection(keyMap[event.code]);
            if (!this.isRunning) this.start();
            return;
        }

        if (event.code === 'Space') {
            event.preventDefault();
            this.togglePause();
            return;
        }

        if (event.code === 'Enter' && this.gameOver) {
            event.preventDefault();
            this.reset();
            this.start();
        }
    }

    setDirection(directionName) {
        const directions = {
            up: { x: 0, y: -1 },
            down: { x: 0, y: 1 },
            left: { x: -1, y: 0 },
            right: { x: 1, y: 0 },
        };
        const next = directions[directionName];
        if (!next) return;

        const isOpposite = this.direction.x + next.x === 0 && this.direction.y + next.y === 0;
        if (!isOpposite) {
            this.nextDirection = next;
        }
    }

    start() {
        if (this.gameOver) this.resetState();
        if (this.isRunning) return;

        this.isRunning = true;
        this.isPaused = false;
        this.canvas.focus();
        this.timer = window.setInterval(() => this.tick(), this.tickMs);
        this.updateUi();
        this.render();
    }

    togglePause() {
        if (!this.isRunning && !this.gameOver) {
            this.start();
            return;
        }
        if (this.gameOver) return;

        this.isPaused = !this.isPaused;
        this.updateUi();
        this.render();
    }

    reset() {
        this.stopTimer();
        this.isRunning = false;
        this.resetState();
        this.updateUi();
        this.render();
    }

    stopTimer() {
        if (this.timer) {
            window.clearInterval(this.timer);
            this.timer = null;
        }
    }

    tick() {
        if (this.isPaused || this.gameOver) return;

        this.direction = this.nextDirection;
        const head = this.snake[0];
        const nextHead = {
            x: head.x + this.direction.x,
            y: head.y + this.direction.y,
        };

        if (this.hasCollision(nextHead)) {
            this.finishGame();
            return;
        }

        this.snake.unshift(nextHead);

        if (nextHead.x === this.food.x && nextHead.y === this.food.y) {
            this.score += 1;
            this.food = this.createFood();
            this.updateUi();
        } else {
            this.snake.pop();
        }

        this.render();
    }

    hasCollision(point) {
        const hitsWall = point.x < 0 || point.y < 0 || point.x >= this.gridSize || point.y >= this.gridSize;
        const hitsSelf = this.snake.some((segment) => segment.x === point.x && segment.y === point.y);
        return hitsWall || hitsSelf;
    }

    createFood() {
        const occupied = new Set(this.snake.map((segment) => `${segment.x}:${segment.y}`));
        let point;
        do {
            point = {
                x: Math.floor(Math.random() * this.gridSize),
                y: Math.floor(Math.random() * this.gridSize),
            };
        } while (occupied.has(`${point.x}:${point.y}`));
        return point;
    }

    finishGame() {
        this.gameOver = true;
        this.isRunning = false;
        this.stopTimer();

        if (this.score > this.best) {
            this.best = this.score;
            localStorage.setItem(this.storageKey, String(this.best));
        }

        this.updateUi();
        this.render();
    }

    updateUi() {
        if (this.scoreElement) this.scoreElement.textContent = this.score;
        if (this.bestElement) this.bestElement.textContent = this.best;
        if (this.pauseButton) this.pauseButton.textContent = this.isPaused ? 'Продолжить' : 'Пауза';
        if (this.startButton) this.startButton.textContent = this.gameOver ? 'Заново' : 'Старт';
    }

    render() {
        this.clearCanvas();
        this.drawGrid();
        this.drawFood();
        this.drawSnake();

        if (!this.isRunning && !this.gameOver && this.score === 0) {
            this.drawOverlay('Нажмите Старт или стрелку', 'WASD / стрелки для движения');
        }
        if (this.isPaused) {
            this.drawOverlay('Пауза', 'Пробел — продолжить');
        }
        if (this.gameOver) {
            this.drawOverlay('Игра окончена', 'Enter или Старт — заново');
        }
    }

    clearCanvas() {
        this.ctx.fillStyle = '#ffffff';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    }

    drawGrid() {
        this.ctx.strokeStyle = '#eef0f3';
        this.ctx.lineWidth = 1;
        for (let i = 0; i <= this.gridSize; i += 1) {
            const pos = i * this.cellSize;
            this.ctx.beginPath();
            this.ctx.moveTo(pos, 0);
            this.ctx.lineTo(pos, this.canvas.height);
            this.ctx.stroke();
            this.ctx.beginPath();
            this.ctx.moveTo(0, pos);
            this.ctx.lineTo(this.canvas.width, pos);
            this.ctx.stroke();
        }
    }

    drawSnake() {
        this.snake.forEach((segment, index) => {
            this.ctx.fillStyle = index === 0 ? '#111827' : '#374151';
            this.roundRect(
                segment.x * this.cellSize + 2,
                segment.y * this.cellSize + 2,
                this.cellSize - 4,
                this.cellSize - 4,
                6,
            );
            this.ctx.fill();
        });
    }

    drawFood() {
        const x = this.food.x * this.cellSize + this.cellSize / 2;
        const y = this.food.y * this.cellSize + this.cellSize / 2;
        this.ctx.fillStyle = '#b91c1c';
        this.ctx.beginPath();
        this.ctx.arc(x, y, this.cellSize * 0.32, 0, Math.PI * 2);
        this.ctx.fill();
    }

    drawOverlay(title, subtitle) {
        this.ctx.fillStyle = 'rgba(255, 255, 255, 0.86)';
        this.ctx.fillRect(48, 176, this.canvas.width - 96, 128);
        this.ctx.strokeStyle = '#e5e7eb';
        this.ctx.strokeRect(48, 176, this.canvas.width - 96, 128);
        this.ctx.fillStyle = '#111827';
        this.ctx.font = '700 28px system-ui';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(title, this.canvas.width / 2, 226);
        this.ctx.fillStyle = '#6b7280';
        this.ctx.font = '16px system-ui';
        this.ctx.fillText(subtitle, this.canvas.width / 2, 260);
        this.ctx.textAlign = 'start';
    }

    roundRect(x, y, width, height, radius) {
        this.ctx.beginPath();
        this.ctx.moveTo(x + radius, y);
        this.ctx.lineTo(x + width - radius, y);
        this.ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
        this.ctx.lineTo(x + width, y + height - radius);
        this.ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
        this.ctx.lineTo(x + radius, y + height);
        this.ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
        this.ctx.lineTo(x, y + radius);
        this.ctx.quadraticCurveTo(x, y, x + radius, y);
        this.ctx.closePath();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('snakeCanvas');
    if (!canvas) return;

    window.snakeGame = new SnakeGame({
        canvas,
        scoreElement: document.querySelector('[data-snake-score]'),
        bestElement: document.querySelector('[data-snake-best]'),
        startButton: document.querySelector('[data-snake-start]'),
        pauseButton: document.querySelector('[data-snake-pause]'),
        resetButton: document.querySelector('[data-snake-reset]'),
        mobileButtons: document.querySelectorAll('[data-snake-dir]'),
        gridSize: 24,
        tickMs: 110,
    });
});
