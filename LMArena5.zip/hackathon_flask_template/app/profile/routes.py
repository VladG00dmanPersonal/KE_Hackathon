import os
from uuid import uuid4

from flask import Blueprint, current_app, flash, g, redirect, render_template, request, url_for
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

from ..auth.decorators import login_required
from ..db import execute, query_all, query_one

bp = Blueprint("profile", __name__)

ALLOWED_IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "gif"}


def allowed_image(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_IMAGE_EXTENSIONS


def save_topup_proof(file_storage):
    original = secure_filename(file_storage.filename or "")
    if not original or not allowed_image(original):
        raise ValueError("Загрузите изображение оплаты: png, jpg, jpeg, webp или gif.")

    ext = original.rsplit(".", 1)[1].lower()
    filename = f"{uuid4().hex}.{ext}"
    relative_path = os.path.join("uploads", "topups", filename).replace("\\", "/")
    absolute_path = os.path.join(current_app.static_folder, relative_path)
    os.makedirs(os.path.dirname(absolute_path), exist_ok=True)
    file_storage.save(absolute_path)
    return relative_path


@bp.route("/", methods=("GET", "POST"))
@login_required
def index():
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        phone = request.form.get("phone", "").strip()
        execute(
            "UPDATE users SET full_name = ?, phone = ? WHERE id = ?",
            (full_name, phone, g.user["id"]),
            commit=True,
        )
        flash("Профиль обновлён. Почта остаётся неизменной.", "success")
        return redirect(url_for("profile.index"))

    stats = {
        "cart_count": query_one("SELECT COALESCE(SUM(quantity), 0) AS value FROM cart_items WHERE user_id = ?", (g.user["id"],))["value"],
        "events_count": query_one("SELECT COUNT(*) AS value FROM calendar_events WHERE user_id = ?", (g.user["id"],))["value"],
        "orders_count": query_one("SELECT COUNT(*) AS value FROM orders WHERE user_id = ?", (g.user["id"],))["value"],
        "pending_topups": query_one("SELECT COUNT(*) AS value FROM balance_requests WHERE user_id = ? AND status = 'pending'", (g.user["id"],))["value"],
    }
    orders = query_all(
        """
        SELECT o.*, COUNT(oi.id) AS items_count
        FROM orders o
        LEFT JOIN order_items oi ON oi.order_id = o.id
        WHERE o.user_id = ?
        GROUP BY o.id
        ORDER BY o.created_at DESC, o.id DESC
        LIMIT 10
        """,
        (g.user["id"],),
    )
    topup_requests = query_all(
        """
        SELECT * FROM balance_requests
        WHERE user_id = ?
        ORDER BY created_at DESC, id DESC
        LIMIT 10
        """,
        (g.user["id"],),
    )
    return render_template("profile/index.html", stats=stats, orders=orders, topup_requests=topup_requests)


@bp.route("/top-up", methods=("POST",))
@login_required
def top_up():
    raw_amount = request.form.get("amount", "").strip()
    try:
        amount = int(raw_amount)
    except ValueError:
        flash("Сумма пополнения должна быть целым числом.", "danger")
        return redirect(url_for("profile.index"))

    if amount <= 0:
        flash("Сумма пополнения должна быть больше нуля.", "danger")
        return redirect(url_for("profile.index"))
    if amount > 1_000_000:
        flash("Для шаблона максимальная сумма одного пополнения — 1 000 000 ₽.", "warning")
        return redirect(url_for("profile.index"))

    proof = request.files.get("proof_image")
    if proof is None or not proof.filename:
        flash("Приложите картинку с подтверждением оплаты.", "danger")
        return redirect(url_for("profile.index"))

    try:
        proof_path = save_topup_proof(proof)
    except ValueError as exc:
        flash(str(exc), "danger")
        return redirect(url_for("profile.index"))

    execute(
        """
        INSERT INTO balance_requests (user_id, amount, proof_image, status)
        VALUES (?, ?, ?, 'pending')
        """,
        (g.user["id"], amount, proof_path),
        commit=True,
    )
    flash("Заявка на пополнение отправлена администратору. Баланс изменится после подтверждения.", "success")
    return redirect(url_for("profile.index"))


@bp.route("/change-password", methods=("POST",))
@login_required
def change_password():
    current_password = request.form.get("current_password", "")
    new_password = request.form.get("new_password", "")
    new_password_confirm = request.form.get("new_password_confirm", "")

    user = query_one("SELECT password_hash FROM users WHERE id = ?", (g.user["id"],))
    if user is None or not check_password_hash(user["password_hash"], current_password):
        flash("Старый пароль указан неверно.", "danger")
        return redirect(url_for("profile.index"))
    if len(new_password) < 6:
        flash("Новый пароль должен быть не короче 6 символов.", "danger")
        return redirect(url_for("profile.index"))
    if new_password != new_password_confirm:
        flash("Новые пароли не совпадают.", "danger")
        return redirect(url_for("profile.index"))

    execute(
        "UPDATE users SET password_hash = ? WHERE id = ?",
        (generate_password_hash(new_password), g.user["id"]),
        commit=True,
    )
    flash("Пароль изменён.", "success")
    return redirect(url_for("profile.index"))
