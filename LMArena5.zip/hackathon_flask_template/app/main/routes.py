import csv
import io
import os
import sqlite3
from uuid import uuid4

from flask import Blueprint, Response, current_app, flash, jsonify, redirect, render_template, request, url_for
from werkzeug.utils import secure_filename

from ..db import execute, query_all, query_one

bp = Blueprint("main", __name__)

STATUSES = {"new", "in_progress", "done", "cancelled"}


@bp.route("/")
def index():
    return render_template("main/index.html")


def validate_table_record_form():
    title = request.form.get("title", "").strip()
    status = request.form.get("status", "new").strip()
    owner_email = request.form.get("owner_email", "").strip() or None
    raw_amount = request.form.get("amount", "0").strip() or "0"

    try:
        amount = int(raw_amount)
    except ValueError:
        raise ValueError("Сумма должна быть целым числом.")

    if not title:
        raise ValueError("Укажите название записи.")
    if status not in STATUSES:
        raise ValueError("Некорректный статус.")
    if amount < 0:
        raise ValueError("Сумма не может быть отрицательной.")

    return title, status, owner_email, amount


@bp.route("/table", methods=("GET", "POST"))
def table():
    if request.method == "POST":
        try:
            title, status, owner_email, amount = validate_table_record_form()
            execute(
                "INSERT INTO table_records (title, status, owner_email, amount) VALUES (?, ?, ?, ?)",
                (title, status, owner_email, amount),
                commit=True,
            )
            flash("Строка добавлена в таблицу.", "success")
        except ValueError as exc:
            flash(str(exc), "danger")
        except sqlite3.IntegrityError:
            flash("Запись с таким названием уже существует.", "danger")
        return redirect(url_for("main.table"))

    search = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()

    sql = "SELECT * FROM table_records WHERE 1=1"
    params = []
    if search:
        sql += " AND (title LIKE ? OR owner_email LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    if status:
        sql += " AND status = ?"
        params.append(status)
    sql += " ORDER BY created_at DESC, id DESC"

    records = query_all(sql, params)
    statuses = query_all("SELECT DISTINCT status FROM table_records ORDER BY status")
    return render_template("main/table.html", records=records, statuses=statuses, search=search, selected_status=status)


@bp.route("/table/<int:record_id>/edit", methods=("GET", "POST"))
def table_edit(record_id):
    record = query_one("SELECT * FROM table_records WHERE id = ?", (record_id,))
    if record is None:
        flash("Строка не найдена.", "danger")
        return redirect(url_for("main.table"))

    if request.method == "POST":
        try:
            title, status, owner_email, amount = validate_table_record_form()
            execute(
                "UPDATE table_records SET title = ?, status = ?, owner_email = ?, amount = ? WHERE id = ?",
                (title, status, owner_email, amount, record_id),
                commit=True,
            )
            flash("Строка обновлена.", "success")
            return redirect(url_for("main.table"))
        except ValueError as exc:
            flash(str(exc), "danger")
        except sqlite3.IntegrityError:
            flash("Запись с таким названием уже существует.", "danger")

    return render_template("main/table_form.html", record=record, statuses=STATUSES)


@bp.route("/table/<int:record_id>/delete", methods=("POST",))
def table_delete(record_id):
    execute("DELETE FROM table_records WHERE id = ?", (record_id,), commit=True)
    flash("Строка удалена.", "info")
    return redirect(url_for("main.table"))


@bp.route("/stats")
def stats():
    summary = {
        "users": query_one("SELECT COUNT(*) AS value FROM users")["value"],
        "products": query_one("SELECT COUNT(*) AS value FROM products")["value"],
        "orders": query_one("SELECT COUNT(*) AS value FROM orders")["value"],
        "revenue": query_one("SELECT COALESCE(SUM(total), 0) AS value FROM orders WHERE status = 'paid'")["value"],
        "pending_topups": query_one("SELECT COUNT(*) AS value FROM balance_requests WHERE status = 'pending'")["value"],
    }
    return render_template("main/stats.html", summary=summary)


@bp.route("/stats/data")
def stats_data():
    by_category = [dict(row) for row in query_all(
        """
        SELECT COALESCE(c.name, 'Без категории') AS label, COUNT(p.id) AS value
        FROM products p
        LEFT JOIN categories c ON c.id = p.category_id
        GROUP BY c.name
        ORDER BY value DESC
        """
    )]
    table_statuses = [dict(row) for row in query_all(
        "SELECT status AS label, COUNT(*) AS value FROM table_records GROUP BY status ORDER BY value DESC"
    )]
    order_days = [dict(row) for row in query_all(
        """
        SELECT substr(created_at, 1, 10) AS label, COALESCE(SUM(total), 0) AS value
        FROM orders
        GROUP BY substr(created_at, 1, 10)
        ORDER BY label ASC
        LIMIT 14
        """
    )]
    top_products = [dict(row) for row in query_all(
        """
        SELECT product_name AS label, SUM(quantity) AS value
        FROM order_items
        GROUP BY product_name
        ORDER BY value DESC
        LIMIT 8
        """
    )]
    return jsonify({
        "byCategory": by_category,
        "tableStatuses": table_statuses,
        "orderDays": order_days,
        "topProducts": top_products,
    })


@bp.route("/stats/export.csv")
def stats_export_csv():
    rows = query_all(
        """
        SELECT o.id AS order_id, u.email, o.status, o.total, o.created_at,
               oi.product_name, oi.price, oi.quantity
        FROM orders o
        JOIN users u ON u.id = o.user_id
        LEFT JOIN order_items oi ON oi.order_id = o.id
        ORDER BY o.created_at DESC, o.id DESC
        """
    )
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["order_id", "email", "status", "total", "created_at", "product_name", "price", "quantity"])
    for row in rows:
        writer.writerow([row["order_id"], row["email"], row["status"], row["total"], row["created_at"], row["product_name"], row["price"], row["quantity"]])
    return Response(
        output.getvalue(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=stats_export.csv"},
    )


@bp.route("/form-demo", methods=("GET", "POST"))
def form_demo():
    result = None
    if request.method == "POST":
        saved_files = []
        for file_storage in request.files.getlist("files"):
            if not file_storage or not file_storage.filename:
                continue
            original = secure_filename(file_storage.filename)
            ext = original.rsplit(".", 1)[1].lower() if "." in original else "bin"
            filename = f"{uuid4().hex}.{ext}"
            relative_path = os.path.join("uploads", "form_demo", filename).replace("\\", "/")
            absolute_path = os.path.join(current_app.static_folder, relative_path)
            os.makedirs(os.path.dirname(absolute_path), exist_ok=True)
            file_storage.save(absolute_path)
            saved_files.append({
                "original": original,
                "path": relative_path,
                "is_image": ext in {"png", "jpg", "jpeg", "webp", "gif"},
            })

        result = {
            "title": request.form.get("title"),
            "description": request.form.get("description"),
            "quantity": request.form.get("quantity"),
            "rating": request.form.get("rating"),
            "priority": request.form.get("priority"),
            "features": request.form.getlist("features"),
            "is_public": bool(request.form.get("is_public")),
            "files": saved_files,
        }
        flash("Форма обработана. Ниже показан пример результата.", "success")

    return render_template("main/form_demo.html", result=result)
