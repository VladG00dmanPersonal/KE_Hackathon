import os
from flask import Flask, g, render_template

from config import Config
from . import db


def create_app(config_class=Config):
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(config_class)

    os.makedirs(os.path.dirname(app.config["DATABASE"]), exist_ok=True)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    os.makedirs(os.path.join(app.config["UPLOAD_FOLDER"], "topups"), exist_ok=True)
    os.makedirs(os.path.join(app.config["UPLOAD_FOLDER"], "form_demo"), exist_ok=True)

    db.init_app(app)

    from .auth.routes import bp as auth_bp
    from .main.routes import bp as main_bp
    from .products.routes import bp as products_bp
    from .cart.routes import bp as cart_bp
    from .calendar.routes import bp as calendar_bp
    from .profile.routes import bp as profile_bp
    from .admin.routes import bp as admin_bp
    from .game.routes import bp as game_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(products_bp, url_prefix="/products")
    app.register_blueprint(cart_bp, url_prefix="/cart")
    app.register_blueprint(calendar_bp, url_prefix="/calendar")
    app.register_blueprint(profile_bp, url_prefix="/profile")
    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(game_bp, url_prefix="/game")

    @app.template_filter("price")
    def price_filter(value):
        try:
            return f"{int(value):,}".replace(",", " ") + " ₽"
        except (TypeError, ValueError):
            return "0 ₽"

    @app.template_filter("status")
    def status_filter(value):
        labels = {
            "new": "Новая",
            "in_progress": "В работе",
            "done": "Готово",
            "cancelled": "Отменено",
            "paid": "Оплачен",
            "refunded": "Возврат",
            "pending": "На проверке",
            "approved": "Подтверждено",
            "rejected": "Отклонено",
        }
        return labels.get(value, value)

    @app.context_processor
    def inject_current_user():
        return {"current_user": getattr(g, "user", None)}

    @app.errorhandler(403)
    def forbidden(error):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(error):
        return render_template("errors/404.html"), 404

    return app
