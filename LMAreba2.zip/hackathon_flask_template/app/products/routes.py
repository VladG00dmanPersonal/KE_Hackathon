from flask import Blueprint, abort, render_template, request

from ..db import query_all, query_one

bp = Blueprint("products", __name__)


def _to_int(value):
    try:
        return int(value) if value not in (None, "") else None
    except ValueError:
        return None


@bp.route("/")
def catalog():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    min_price = _to_int(request.args.get("min_price"))
    max_price = _to_int(request.args.get("max_price"))
    in_stock = request.args.get("in_stock") == "1"
    sort = request.args.get("sort", "new")

    sql = """
        SELECT p.*, c.name AS category_name, c.slug AS category_slug
        FROM products p
        LEFT JOIN categories c ON c.id = p.category_id
        WHERE 1=1
    """
    params = []

    if q:
        sql += " AND p.name LIKE ?"
        params.append(f"%{q}%")
    if category:
        sql += " AND c.slug = ?"
        params.append(category)
    if min_price is not None:
        sql += " AND p.price >= ?"
        params.append(min_price)
    if max_price is not None:
        sql += " AND p.price <= ?"
        params.append(max_price)
    if in_stock:
        sql += " AND p.in_stock = 1"

    order_by = {
        "new": "p.created_at DESC, p.id DESC",
        "price_asc": "p.price ASC",
        "price_desc": "p.price DESC",
        "name": "p.name ASC",
    }.get(sort, "p.created_at DESC, p.id DESC")
    sql += f" ORDER BY {order_by}"

    products = query_all(sql, params)
    categories = query_all("SELECT * FROM categories ORDER BY name")

    return render_template(
        "products/catalog.html",
        products=products,
        categories=categories,
        filters={
            "q": q,
            "category": category,
            "min_price": min_price or "",
            "max_price": max_price or "",
            "in_stock": in_stock,
            "sort": sort,
        },
    )


@bp.route("/<slug>")
def detail(slug):
    product = query_one(
        """
        SELECT p.*, c.name AS category_name, c.slug AS category_slug
        FROM products p
        LEFT JOIN categories c ON c.id = p.category_id
        WHERE p.slug = ?
        """,
        (slug,),
    )
    if product is None:
        abort(404)

    related = query_all(
        """
        SELECT p.*, c.name AS category_name
        FROM products p
        LEFT JOIN categories c ON c.id = p.category_id
        WHERE p.id != ? AND (p.category_id = ? OR ? IS NULL)
        ORDER BY p.created_at DESC
        LIMIT 3
        """,
        (product["id"], product["category_id"], product["category_id"]),
    )
    return render_template("products/detail.html", product=product, related=related)
