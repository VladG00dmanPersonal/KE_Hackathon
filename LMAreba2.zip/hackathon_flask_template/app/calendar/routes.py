import calendar as calendar_module
from collections import defaultdict
from datetime import date, datetime

from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from ..auth.decorators import login_required
from ..db import execute, query_all

bp = Blueprint("calendar", __name__)

MONTH_NAMES_RU = [
    "", "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
]


@bp.route("/", methods=("GET", "POST"))
@login_required
def index():
    if request.method == "POST":
        event_date = request.form.get("event_date", "").strip()
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()

        error = None
        try:
            parsed_date = datetime.strptime(event_date, "%Y-%m-%d").date()
        except ValueError:
            parsed_date = None
            error = "Укажите дату в формате ГГГГ-ММ-ДД."
        if not title:
            error = "Укажите название события."

        if error:
            flash(error, "danger")
        else:
            execute(
                """
                INSERT INTO calendar_events (user_id, event_date, title, description)
                VALUES (?, ?, ?, ?)
                """,
                (g.user["id"], parsed_date.isoformat(), title, description),
                commit=True,
            )
            flash("Запись добавлена в календарь.", "success")
            return redirect(url_for("calendar.index", year=parsed_date.year, month=parsed_date.month))

    today = date.today()
    year = request.args.get("year", today.year, type=int)
    month = request.args.get("month", today.month, type=int)
    if month < 1 or month > 12:
        year, month = today.year, today.month

    month_matrix = calendar_module.Calendar(firstweekday=0).monthdatescalendar(year, month)
    start_date = month_matrix[0][0]
    end_date = month_matrix[-1][-1]

    rows = query_all(
        """
        SELECT * FROM calendar_events
        WHERE user_id = ? AND event_date BETWEEN ? AND ?
        ORDER BY event_date ASC, created_at ASC
        """,
        (g.user["id"], start_date.isoformat(), end_date.isoformat()),
    )
    events_by_date = defaultdict(list)
    for row in rows:
        events_by_date[row["event_date"]].append(row)

    prev_year = year if month > 1 else year - 1
    prev_month = month - 1 if month > 1 else 12
    next_year = year if month < 12 else year + 1
    next_month = month + 1 if month < 12 else 1

    return render_template(
        "calendar/index.html",
        month_matrix=month_matrix,
        events_by_date=events_by_date,
        year=year,
        month=month,
        month_name=MONTH_NAMES_RU[month],
        today=today,
        prev_year=prev_year,
        prev_month=prev_month,
        next_year=next_year,
        next_month=next_month,
    )


@bp.route("/delete/<int:event_id>", methods=("POST",))
@login_required
def delete(event_id):
    execute("DELETE FROM calendar_events WHERE id = ? AND user_id = ?", (event_id, g.user["id"]), commit=True)
    flash("Запись удалена.", "info")
    return redirect(request.referrer or url_for("calendar.index"))
