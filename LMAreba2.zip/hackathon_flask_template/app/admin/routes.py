import re
import sqlite3
from datetime import datetime

from flask import Blueprint, flash, redirect, render_template, request, url_for

from ..auth.decorators import roles_required
from ..db import execute, query_all, query_one

bp = Blueprint("admin", __name__)

CYRILLIC_MAP = str.maketrans({
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e",
    "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
    "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
    "ф": "f", "х": "h", "ц": "c", "ч": "ch", "ш": "sh", "щ": "sch", "ъ": "",
    "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
})


def slugify(value):
    value = (value or "").strip().lower().translate(CYRILLIC_MAP)
    value = re.sub(r"[^a-z0-9]+", "-", value).strip("-")
    return value


def unique_slug(base, table_name):
    base = slugify(base) or f"item-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
    slug = base
    counter = 2
    while query_one(f"SELECT id FROM {table_name} WHERE slug = ?", (slug,)):
        slug = f"{base}-{counter}"
        counter += 1
    return slug


def parse_money(value, field_name="Сумма"):
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        raise ValueError(f"{field_name} должна быть целым числом.")
    if parsed < 0:
        raise ValueError(f"{field_name} не может быть отрицательной.")
    return parsed


@bp.route("/")
@roles_required("admin")
def dashboard():
    stats = {
        "users": query_one("SELECT COUNT(*) AS value FROM users")["value"],
        "products": query_one("SELECT COUNT(*) AS value FROM products")["value"],
        "events": query_one("SELECT COUNT(*) AS value FROM calendar_events")["value"],
        "cart_items": query_one("SELECT COUNT(*) AS value FROM cart_items")["value"],
        "orders": query_one("SELECT COUNT(*) AS value FROM orders")["value"],
    }
    return render_template("admin/dashboard.html", stats=stats)


@bp.route("/users", methods=("GET", "POST"))
@roles_required("admin")
def users():
    if request.method == "POST":
        user_id = request.form.get("user_id", type=int)
        role = request.form.get("role", "user")
        if role not in {"user", "manager", "admin"}:
            flash("Некорректная роль.", "danger")
        else:
            execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id), commit=True)
            flash("Роль пользователя обновлена.", "success")
        return redirect(url_for("admin.users"))

    users = query_all("SELECT id, email, role, full_name, balance, created_at FROM users ORDER BY created_at DESC")
    return render_template("admin/users.html", users=users)


@bp.route("/products")
@roles_required("admin")
def products():
    products = query_all(
        """
        SELECT p.*, c.name AS category_name
        FROM products p
        LEFT JOIN categories c ON c.id = p.category_id
        ORDER BY p.created_at DESC
        """
    )
    return render_template("admin/products.html", products=products)


@bp.route("/products/new", methods=("GET", "POST"))
@roles_required("admin")
def product_new():
    categories = query_all("SELECT * FROM categories ORDER BY name")

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        slug = request.form.get("slug", "").strip()
        description = request.form.get("description", "").strip()
        category_id = request.form.get("category_id", type=int)
        new_category = request.form.get("new_category", "").strip()
        in_stock = 1 if request.form.get("in_stock") == "1" else 0
        image_url = request.form.get("image_url", "").strip() or None

        try:
            price = parse_money(request.form.get("price"), "Цена")
        except ValueError as exc:
            flash(str(exc), "danger")
            return render_template("admin/product_form.html", categories=categories, form=request.form)

        if not name:
            flash("Укажите название товара.", "danger")
            return render_template("admin/product_form.html", categories=categories, form=request.form)

        if new_category:
            category_slug = unique_slug(new_category, "categories")
            execute(
                "INSERT INTO categories (slug, name) VALUES (?, ?)",
                (category_slug, new_category),
                commit=True,
            )
            category_id = query_one("SELECT id FROM categories WHERE slug = ?", (category_slug,))["id"]

        product_slug = slugify(slug) if slug else unique_slug(name, "products")
        if not product_slug:
            product_slug = unique_slug(name, "products")

        if query_one("SELECT id FROM products WHERE slug = ?", (product_slug,)):
            flash("Товар с таким slug уже существует. Укажите другой slug.", "danger")
            return render_template("admin/product_form.html", categories=categories, form=request.form)

        try:
            execute(
                """
                INSERT INTO products (slug, name, description, price, image_url, category_id, in_stock)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (product_slug, name, description, price, image_url, category_id, in_stock),
                commit=True,
            )
        except sqlite3.IntegrityError:
            flash("Не удалось добавить товар. Проверьте уникальность slug и категорию.", "danger")
            return render_template("admin/product_form.html", categories=categories, form=request.form)

        flash("Товар добавлен.", "success")
        return redirect(url_for("admin.products"))

    return render_template("admin/product_form.html", categories=categories, form={})
