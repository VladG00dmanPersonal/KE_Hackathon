import sqlite3

from flask import Blueprint, flash, redirect, render_template, request, url_for

from ..db import execute, query_all

bp = Blueprint("main", __name__)

STATUSES = {"new", "in_progress", "done", "cancelled"}


@bp.route("/")
def index():
    return render_template("main/index.html")


@bp.route("/table", methods=("GET", "POST"))
def table():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        status = request.form.get("status", "new").strip()
        owner_email = request.form.get("owner_email", "").strip() or None
        raw_amount = request.form.get("amount", "0").strip() or "0"

        try:
            amount = int(raw_amount)
        except ValueError:
            flash("Сумма должна быть целым числом.", "danger")
            return redirect(url_for("main.table"))

        if not title:
            flash("Укажите название записи.", "danger")
            return redirect(url_for("main.table"))
        if status not in STATUSES:
            flash("Некорректный статус.", "danger")
            return redirect(url_for("main.table"))
        if amount < 0:
            flash("Сумма не может быть отрицательной.", "danger")
            return redirect(url_for("main.table"))

        try:
            execute(
                "INSERT INTO table_records (title, status, owner_email, amount) VALUES (?, ?, ?, ?)",
                (title, status, owner_email, amount),
                commit=True,
            )
            flash("Строка добавлена в таблицу.", "success")
        except sqlite3.IntegrityError:
            flash("Запись с таким названием уже существует.", "danger")
        return redirect(url_for("main.table"))

    search = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()

    sql = "SELECT * FROM table_records WHERE 1=1"
    params = []
    if search:
        sql += " AND (title LIKE ? OR owner_email LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    if status:
        sql += " AND status = ?"
        params.append(status)
    sql += " ORDER BY created_at DESC, id DESC"

    records = query_all(sql, params)
    statuses = query_all("SELECT DISTINCT status FROM table_records ORDER BY status")
    return render_template("main/table.html", records=records, statuses=statuses, search=search, selected_status=status)
